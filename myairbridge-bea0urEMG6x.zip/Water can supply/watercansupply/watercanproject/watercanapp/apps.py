from django.apps import AppConfig


class WatercanappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'watercanapp'
